
import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'

const App = () => (
  <main className="p-4 md:p-8 space-y-6">
    <section className="text-center">
      <h1 className="text-4xl font-bold mb-2">English with Girish</h1>
      <p className="text-lg">Expert Online Tutoring & English Lessons</p>
    </section>

    <section className="grid md:grid-cols-2 gap-4">
      <div className="bg-white rounded-xl shadow p-4">
        <h2 className="text-xl font-semibold mb-2">About Me</h2>
        <p>
          I’m Girish, an experienced English tutor with over 15 years of classroom and 6 years of online teaching.
          I specialize in test prep, business English, and helping students build confidence in speaking, writing, reading, and listening.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Classes</h2>
        <p>
          I offer 1-on-1 and group sessions tailored for all age groups. My sessions cover IELTS, TOEFL, Business English,
          Academic Writing, and Creative English for kids.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Testimonials</h2>
        <p>
          “Thanks to Girish’s IELTS coaching, I scored a Band 8!” – Rahul M.<br />
          “My child’s spoken English improved drastically in just 3 months.” – Ananya P.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow p-4">
        <h2 className="text-xl font-semibold mb-2">Blog</h2>
        <p>Coming soon: tips for English learners, grammar hacks, vocabulary builders, and more.</p>
      </div>
    </section>

    <section className="text-center mt-10">
      <h2 className="text-2xl font-bold mb-4">Contact Me</h2>
      <p>Email: girikarthik2012@gmail.com</p>
      <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-xl shadow hover:bg-blue-700">Book a Free Trial Lesson</button>
    </section>
  </main>
)

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
